<?php
    ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );

    mail("alisaadgs@gmail.com","Answer","Hope You Vote My Answer Up","From: alisaadgs@gmail.com");
    echo "L'email a été envoyé.";
?>