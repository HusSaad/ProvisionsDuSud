<!doctype html>
<html lang="en">
    
<?php require('head.php'); ?>
    
<p id="titleDescAbout">Our Story</p>
<p id="txtDescAbout">Our story began when my mother started doing some semolina and sell them ,then we started doing more and more and with time demand has increased We started doing other products like pickles,chickpeas and lentils ,more over we make Keshek ,shanklish,different types of spices and nearly every lebanese supply.We are situated in south Lebanon and we don't use chemmical substances for our products. Nearly all the family work in this business, Mother, Father, Grandparents and sons.We hope you try our products and listen to your reviews.I would like to present you our family business members</p>

    <section id="team">
        <h1 class="heading">
            <!--icon---------------->
            <i class="fas fa-feather-alt"></i> Provisions Du Sud Members
            
        </h1>
        
    <!--container---------------->
    <div class="container">
        <!--box-1----------->
        <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn">
                <label class="heart" for="heart-btn"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About1.jpg" alt="">
                <strong>The GrandFather</strong>
                
            </div>
            
           
        </div>
        <!--box-2----------->
        <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn2">
                <label class="heart" for="heart-btn2"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About2.jpg" alt="">
                <strong>The Mother</strong>
               
            </div>
            
           
        </div>
        <!--box-3----------->
        <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
               
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn3">
                <label class="heart" for="heart-btn3"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About3.jpg" alt="">
                <strong>The Father</strong>
                
            </div>
            
           
        </div>

         <!--box-4----------->
         <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn4">
                <label class="heart" for="heart-btn4"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About4.jpg" alt="">
                <strong>The Angel</strong>
               
            </div>
            
           
        </div>

         <!--box-5----------->
         <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn5">
                <label class="heart" for="heart-btn5"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About5.jpg" alt="">
                <strong>The Brothers</strong>
               
            </div>
            
           
        </div>

         <!--box-6----------->
         <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn6">
                <label class="heart" for="heart-btn6"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About6.jpg" alt="">
                <strong>The GrandMother</strong>
               
            </div>
            
           
        </div>

         <!--box-7----------->
         <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn7">
                <label class="heart" for="heart-btn7"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About7.jpg" alt="">
                <strong>The cousins</strong>
               
            </div>
            
           
        </div>
          <!--box-8----------->
          <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn8">
                <label class="heart" for="heart-btn8"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About8.jpg" alt="">
                <strong> </strong>
               
            </div>
            
           
        </div>
        <!--box-9----------->
        <div class="box">
            <!--top-bar---------------->
            <div class="top-bar"></div>
            <!--nav------------->
            <div class="nav">
                
                <!--heart-btn--------------->
                <input class="heart-btn" type="checkbox" id="heart-btn9">
                <label class="heart" for="heart-btn9"></label>
            </div>
            <!--img and details---------------->
            <div class="details">
                <img src="Images/About9.jpg" alt="">
                <strong> ...</strong>
               
            </div>
            
        
        </div>
    </div>
    </section>
</body>
</html>